# Ashkan Café V3

نسخه کامل Front-end کافه با HTML/CSS/JavaScript خالص.

## امکانات
- منوی آنلاین و Product Detail
- سبد خرید واقعی Front-end با LocalStorage
- Checkout چندمرحله‌ای و Coupon نمونه `CAFE10`
- سفارش آنلاین و تاریخچه سفارش‌ها
- Login/Register نمایشی و پروفایل مشتری
- پنل کاربری، امتیاز وفاداری و رزروها
- Review/Rating UI
- Gift Card دیجیتال
- رزرو میز با انتخاب موقعیت میز
- Events و Blog
- QR Menu واقعی (برای دامنه نمونه؛ پس از Deploy آدرس QR را به دامنه واقعی تغییر دهید)
- فارسی/English UI toggle
- Dark Mode
- PWA: manifest + service worker + icons + offline cache
- Responsive و mobile-first

## نکته
پرداخت، احراز هویت، موجودی واقعی، ثبت سفارش روی سرور و ارسال پیام نیاز به Backend/API دارند. این نسخه عمداً کلید API یا اطلاعات حساس را در Front-end قرار نمی‌دهد.

## Full Persian / English localization
V4 adds a site-wide language system. The selected language is persisted in localStorage and applied on every page, including navigation, cart, product cards, checkout, dashboard, reservations, events, blog, gift cards, reviews, dynamic messages, document `lang`, and RTL/LTR direction.
